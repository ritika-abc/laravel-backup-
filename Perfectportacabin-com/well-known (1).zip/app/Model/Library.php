<?php
App::uses('AppModel', 'Model');
/**
 * Library Model
 *
 */
class Library extends AppModel {

}
