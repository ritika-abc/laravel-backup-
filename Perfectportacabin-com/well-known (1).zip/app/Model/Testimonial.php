<?php
App::uses('AppModel', 'Model');
/**
 * Testimonial Model
 *
 * @property Status $Status
 */
class Testimonial extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	 
}
