<?php

$config = array(
    'Settings' => array(
        'WEBSITE' => 'http://localhost/',
        'SHOP_TITLE' => 'sunrise',
        'ADMIN_EMAIL' => '',
        'DOMAIN' => '',
        'ANALYTICS' => '',
        'PAYPAL_API_USERNAME' => '',
        'PAYPAL_API_PASSWORD' => '',
        'PAYPAL_API_SIGNATURE' => '',
        'AUTHORIZENET_ENABLED' => '',
        'AUTHORIZENET_API_URL' => 'https://test.authorize.net/gateway/transact.dll',
        'AUTHORIZENET_API_LOGIN' => '',
        'AUTHORIZENET_API_TRANSACTION_KEY' => '',
		 
 
 
 
     )
);


